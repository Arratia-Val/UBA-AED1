#ifndef CASES_INCLUDED_H
#define CASES_INCLUDED_H

using namespace std;

bool test01_estaOrdenado();

bool test02_esPrimo();

bool test03_pertenece();

bool test04_desvioEstandar();

bool test05_fibonacci();

bool test06_maximoComunDivisor();

bool test07_sumaDoble();

bool test08_cantPalabras();

bool test09_valorMedio();

bool test10_fraccion();

#endif //CASES_INCLUDED_H
